package domain;

import java.util.ArrayList;

public class Nutrientes {

	private int cdNutriente;

	private String nome;

	private ArrayList<BiscoitoNutriente> biscoitoNutriente = new ArrayList();

	private ArrayList<DCNTpeso> dCNTpeso =  new ArrayList();

    public int getCdNutriente() {
        return cdNutriente;
    }

    public void setCdNutriente(int cdNutriente) {
        this.cdNutriente = cdNutriente;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<BiscoitoNutriente> getBiscoitoNutriente() {
        return biscoitoNutriente;
    }

    public void setBiscoitoNutriente(ArrayList<BiscoitoNutriente> biscoitoNutriente) {
        this.biscoitoNutriente = biscoitoNutriente;
    }

    public ArrayList<DCNTpeso> getdCNTpeso() {
        return dCNTpeso;
    }

    public void setdCNTpeso(ArrayList<DCNTpeso> dCNTpeso) {
        this.dCNTpeso = dCNTpeso;
    }

        
        
          @Override
    public String toString(){
            return this.getNome();
    } 

}
