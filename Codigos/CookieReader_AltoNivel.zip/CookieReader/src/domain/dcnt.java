
package domain;

import java.util.ArrayList;

public class dcnt {

	private int cdDcnt;

	private String nome;

	private ArrayList<DCNTpeso> dCNTpeso = new ArrayList();

    public int getCdDcnt() {
        return cdDcnt;
    }

    public void setCdDcnt(int cdDcnt) {
        this.cdDcnt = cdDcnt;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<DCNTpeso> getdCNTpeso() {
        return dCNTpeso;
    }

    public void setdCNTpeso(ArrayList<DCNTpeso> dCNTpeso) {
        this.dCNTpeso = dCNTpeso;
    }

        

        
          @Override
    public String toString(){
            return this.getNome();
    } 

}
