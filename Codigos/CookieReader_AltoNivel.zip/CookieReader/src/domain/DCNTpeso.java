package domain;

public class DCNTpeso {

	private int peso;

	private Nutrientes nutrientes;

	private dcnt dcnt;


    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public Nutrientes getNutrientes() {
        return nutrientes;
    }

    public void setNutrientes(Nutrientes nutrientes) {
        this.nutrientes = nutrientes;
    }

    public dcnt getDcnt() {
        return dcnt;
    }

    public void setDcnt(dcnt dcnt) {
        this.dcnt = dcnt;
    }
        
    
      @Override
    public String toString(){
            return Integer.toString(this.getPeso());
    } 

}
