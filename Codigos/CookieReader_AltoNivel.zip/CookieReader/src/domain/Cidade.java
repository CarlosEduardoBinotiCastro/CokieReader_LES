package domain;

public class Cidade {

	private int cdCidade;

	private String nome;

	private UF uF;

    public int getCdCidade() {
        return cdCidade;
    }

    public void setCdCidade(int cdCidade) {
        this.cdCidade = cdCidade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public UF getuF() {
        return uF;
    }

    public void setuF(UF uF) {
        this.uF = uF;
    }
        
        
      @Override
    public String toString(){
            return this.getNome();
    } 

}
