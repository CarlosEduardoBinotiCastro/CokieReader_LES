

package domain;

import java.util.ArrayList;

public class Empresa {

	private int cdEmpresa;

	private String nome;

	private ArrayList<Biscoito> biscoito = new ArrayList();

	private Cidade cidade;

    public int getCdEmpresa() {
        return cdEmpresa;
    }

    public void setCdEmpresa(int cdEmpresa) {
        this.cdEmpresa = cdEmpresa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<Biscoito> getBiscoito() {
        return biscoito;
    }

    public void setBiscoito(ArrayList<Biscoito> biscoito) {
        this.biscoito = biscoito;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }

   
        
      @Override
    public String toString(){
            return this.getNome();
    } 
    
}
