package domain;

public class UF {

	private char sigla;

	private String nome;

    public char getSigla() {
        return sigla;
    }

    public void setSigla(char sigla) {
        this.sigla = sigla;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

      @Override
    public String toString(){
            return this.getNome();
    } 
    
}
