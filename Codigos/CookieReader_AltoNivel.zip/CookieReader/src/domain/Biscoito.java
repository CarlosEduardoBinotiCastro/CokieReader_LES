package domain;

import java.util.ArrayList;

public class Biscoito {

	private int cdBiscoito;

	private String nome;

	private Empresa empresa;

	private ArrayList<BiscoitoNutriente> biscoitoNutriente = new ArrayList();

    public int getCdBiscoito() {
        return cdBiscoito;
    }

    public void setCdBiscoito(int cdBiscoito) {
        this.cdBiscoito = cdBiscoito;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public ArrayList<BiscoitoNutriente> getBiscoitoNutriente() {
        return biscoitoNutriente;
    }

    public void setBiscoitoNutriente(ArrayList<BiscoitoNutriente> biscoitoNutriente) {
        this.biscoitoNutriente = biscoitoNutriente;
    }

        

    @Override
    public String toString(){
        return this.getNome();
    } 
    
}
